export class Film {
    public Poster: string;
    public Title: string;
    public Type: string;
    public Year: string;
    public Actors: string;
    public imdbID: string;
}
